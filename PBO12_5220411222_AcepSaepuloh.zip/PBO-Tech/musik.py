import tkinter as tk
from tkinter import filedialog
from pygame import mixer 
class Player:
    def __init__(self, master):
        self.master = master
        self.master.title("Music Player")
        self.master.geometry("400x300")
        self.master.configure(bg="#282828")  # Warna latar belakang serupa dengan Google Play Music

        self.mixer = mixer
        self.mixer.init()

        self.create_widgets()

    def create_widgets(self):
        # Gaya tombol
        button_style = {"bg": "#282828", "fg": "#ffffff", "font": ("Helvetica", 12)}

        # Tombol Play
        self.play_button = tk.Button(self.master, text="▶ Play", command=self.play, **button_style)
        self.play_button.pack(pady=10)

        # Tombol Stop
        self.stop_button = tk.Button(self.master, text="⏹ Stop", command=self.stop, **button_style)
        self.stop_button.pack(pady=10)

        # Tombol Choose File
        self.choose_file_button = tk.Button(self.master, text="Choose File", command=self.choose_file, **button_style)
        self.choose_file_button.pack(pady=10)

    def play(self):
        pass  

    def stop(self):
        self.mixer.music.stop()

    def choose_file(self):
        file_path = filedialog.askopenfilename(filetypes=[("Audio files", "*.mp3;*.wav")])
        if file_path:
            self.play_file(file_path)

    def play_file(self, file_path):
        pass  

class MP3Player(Player):
    def play(self):
        self.mixer.music.load(self.file_path)
        self.mixer.music.play()

    def play_file(self, file_path):
        self.file_path = file_path
        self.play()

if __name__ == "__main__":
    root = tk.Tk()
    app = MP3Player(root)
    root.mainloop()
