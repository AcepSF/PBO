import threading
import time
import os
import sys
from flappy import FlappyBirdGame
from snake2 import SnakeGame
from webBrowser import Browser
from PyQt5.QtWidgets import QApplication
from musik import MP3Player
import tkinter as tk


def login(name, password):
    sukses = False
    file = open("login.txt", "r")
    for i in file:
        a, b = i.split(",")
        b = b.strip()

        if a == name and b == password:
            sukses = True
            break

    file.close()
    if sukses:
        loading_thread = threading.Thread(target=show_loading)
        loading_thread.start()
        loading_thread.join()
        show_running_text("Selamat datang, " + "ACEP SAEPULOH FATAH" + "!")
        # # menuprogram()
        # if __name__ == "__main__":
        #     menuprogram()
    else:
        print("Username atau password yang Anda masukkan salah")

def show_loading():
    print("Loading...", end='', flush=True)
    animation = "|/-\\"
    for i in range(25):
        time.sleep(0.1)
        print(f"\b{animation[i % len(animation)]}", end='', flush=True)
    print("\b Done!")
    
def show_running_text(text):
    for char in text:
        print(char, end='', flush=True)
        time.sleep(0.1)
    print('\n')

def user():
    global name
    print("--------------------------------------------------------")
    print("|===================== Menu Login =====================|")
    print("--------------------------------------------------------\n")
    print()
    name = input("Masukkan Username: ")
    password = input("Masukkan Password: ")
    os.system('cls')
    print()
    login(name, password)

user()


def menuprogram():
    print("---------------------------------------------------------")
    print("|===================== Menu Program =====================|")
    print("---------------------------------------------------------\n")
    lanjut = True
    while lanjut:
        print("--------------------------------------------------------")
        print("=> Daftar Menu \n")
        print(" 1. Mini Game")
        print(" 2. Web Browser")
        print(" 3. Musik Player")
        print(" 0. Keluar\n")
        print("--------------------------------------------------------\n")
        pilih = int(input("Menu yang anda pilih 1/2/3/0 ? : "))
        os.system('cls')
        if pilih == 1:
            print("---------------------------------------------------------")
            print("|===================== Menu Game =====================|")
            print("---------------------------------------------------------\n")
            lanjut_game = True
            while lanjut_game:
                print("--------------------------------------------------------")
                print("=> Daftar Menu \n")
                print(" 1. Flappy Bird")
                print(" 2. Snake")
                print(" 0. Kembali ke Menu Utama")
                print("--------------------------------------------------------\n")
                pilih_game = int(input("Menu yang anda pilih 1/2/3/0 ? : "))
                if pilih_game == 1:
                    if __name__ == '__main__':
                        flappy_game = FlappyBirdGame()
                        flappy_game.game_loop()
                elif pilih_game == 2:
                    if __name__ == "__main__":
                        snake_game = SnakeGame()
                        snake_game.run_game()
                        print("Game Selesai. Kembali ke Menu Utama...")
                        break 
                elif pilih_game == 0:
                    lanjut_game = False
                else:
                    print("Pilihan tidak valid. Silakan pilih 1, 2, atau 0.")
        elif pilih == 2:
            if __name__ == '__main__':
                app = QApplication(sys.argv)
                browser = Browser()
                browser.show()
                sys.exit(app.exec_())
        elif pilih == 3:
            if __name__ == "__main__":
                root = tk.Tk()
                app = MP3Player(root)
                root.mainloop()
        elif pilih == 0:
            exit()
        else:
            lanjut = False
            break

if __name__ == "__main__":
    menuprogram()
# menuprogram()
