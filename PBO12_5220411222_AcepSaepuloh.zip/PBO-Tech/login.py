from menu import menuprogram
import os
import threading
import time

def login(name, password):
    sukses = False
    file = open("login.txt", "r")
    for i in file:
        a, b = i.split(",")
        b = b.strip()

        if a == name and b == password:
            sukses = True
            break

    file.close()
    if sukses:
        loading_thread = threading.Thread(target=show_loading)
        loading_thread.start()
        loading_thread.join()
        show_running_text("Selamat datang, " + "ACEP SAEPULOH FATAH" + "!")
        # # menuprogram()
        # if __name__ == "__main__":
        #     menuprogram()
    else:
        print("Username atau password yang Anda masukkan salah")

def show_loading():
    print("Loading...", end='', flush=True)
    animation = "|/-\\"
    for i in range(25):
        time.sleep(0.1)
        print(f"\b{animation[i % len(animation)]}", end='', flush=True)
    print("\b Done!")
    
def show_running_text(text):
    for char in text:
        print(char, end='', flush=True)
        time.sleep(0.1)
    print('\n')

def user():
    global name
    print("--------------------------------------------------------")
    print("|===================== Menu Login =====================|")
    print("--------------------------------------------------------\n")
    print()
    name = input("Masukkan Username: ")
    password = input("Masukkan Password: ")
    os.system('cls')
    print()
    login(name, password)

user()
