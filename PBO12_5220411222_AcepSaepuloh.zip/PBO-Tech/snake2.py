import pygame
import sys
import random

class Block(pygame.sprite.Sprite):
    def __init__(self, color, width, height):
        super().__init__()
        self.image = pygame.Surface([width, height])
        self.image.fill(color)
        self.rect = self.image.get_rect()

class Snake(pygame.sprite.Group):
    def __init__(self, color, initial_length):
        super().__init__()
        self.direction = "RIGHT"
        self.head = Block(color, SnakeGame.BLOCK_SIZE, SnakeGame.BLOCK_SIZE)
        self.add(self.head)
        self.length = 1
        self.grow(initial_length - 1)

    def move(self):
        if self.direction == "UP":
            self.head.rect.y -= SnakeGame.BLOCK_SIZE
        elif self.direction == "DOWN":
            self.head.rect.y += SnakeGame.BLOCK_SIZE
        elif self.direction == "LEFT":
            self.head.rect.x -= SnakeGame.BLOCK_SIZE
        elif self.direction == "RIGHT":
            self.head.rect.x += SnakeGame.BLOCK_SIZE

    def grow(self, amount):
        for _ in range(amount):
            new_block = Block(SnakeGame.RED, SnakeGame.BLOCK_SIZE, SnakeGame.BLOCK_SIZE)
            self.add(new_block)

class Food(Block):
    def __init__(self, color):
        super().__init__(color, SnakeGame.BLOCK_SIZE, SnakeGame.BLOCK_SIZE)
        self.spawn()

    def spawn(self):
        self.rect.x = random.randrange(0, SnakeGame.SCREEN_WIDTH, SnakeGame.BLOCK_SIZE)
        self.rect.y = random.randrange(0, SnakeGame.SCREEN_HEIGHT, SnakeGame.BLOCK_SIZE)

class SnakeGame:
    SCREEN_WIDTH = 400
    SCREEN_HEIGHT = 400
    BLOCK_SIZE = 20
    SNAKE_SPEED = 9

    WHITE = (255, 255, 255)
    RED = (255, 0, 0)
    GREEN = (0, 255, 0)
    BLACK = (0, 0, 0)

    def __init__(self):
        # Inisialisasi Pygame
        pygame.init()

        # Inisialisasi Pygame dan layar permainan
        self.screen = pygame.display.set_mode((SnakeGame.SCREEN_WIDTH, SnakeGame.SCREEN_HEIGHT))
        pygame.display.set_caption("Snake Game")
        self.clock = pygame.time.Clock()

        self.snake = Snake(SnakeGame.GREEN, 3)
        self.food_group = pygame.sprite.GroupSingle(Food(SnakeGame.BLACK)) 

    def run_game(self):
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_UP and self.snake.direction != "DOWN":
                        self.snake.direction = "UP"
                    elif event.key == pygame.K_DOWN and self.snake.direction != "UP":
                        self.snake.direction = "DOWN"
                    elif event.key == pygame.K_LEFT and self.snake.direction != "RIGHT":
                        self.snake.direction = "LEFT"
                    elif event.key == pygame.K_RIGHT and self.snake.direction != "LEFT":
                        self.snake.direction = "RIGHT"

            self.snake.move()

            if pygame.sprite.spritecollide(self.snake.head, self.food_group, True):
                if self.food_group.sprite and self.food_group.sprite.image.get_at((0, 0)) == SnakeGame.BLACK:
                    self.snake.grow(1)
                self.food_group.add(Food(SnakeGame.BLACK))

            if (
                self.snake.head.rect.x < 0
                or self.snake.head.rect.x >= SnakeGame.SCREEN_WIDTH
                or self.snake.head.rect.y < 0
                or self.snake.head.rect.y >= SnakeGame.SCREEN_HEIGHT
            ):
                pygame.quit()
                sys.exit()

            if len(pygame.sprite.spritecollide(self.snake.head, self.snake, False)) > 1:
                pygame.quit()
                sys.exit()

            self.screen.fill(SnakeGame.WHITE)
            self.snake.draw(self.screen)
            self.food_group.draw(self.screen)
            pygame.display.flip()

            # frame rate
            self.clock.tick(self.SNAKE_SPEED)

# dijalankan sebagai program utama
if __name__ == "__main__":
    game = SnakeGame()
    game.run_game()
